package com.example.test_1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ShowBillActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_show_bill);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Fetch the total amount from the intent
        int total = getIntent().getIntExtra("Total", 0);  // Default value set to 0
        System.out.println(total + " Got from backend");

      // Display the total amount
        TextView edit_total_bill = findViewById(R.id.edit_total_bill);
        String totalStr = String.valueOf(total);  // Correct method to convert int to String
        edit_total_bill.setText("Total Amount: ₹" + totalStr);

        Button logout_button2 = findViewById(R.id.logout_button2);

        logout_button2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ShowBillActivity.this, MainActivity.class);
                Toast.makeText(ShowBillActivity.this, "Logout Button clicked", Toast.LENGTH_SHORT).show();
                startActivity(intent);

            }
        });

        Button back_to_bill_generation = findViewById(R.id.back_to_bill_generation);

        back_to_bill_generation.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ShowBillActivity.this, BillGenerationActivity.class);
                Toast.makeText(ShowBillActivity.this, "Going back", Toast.LENGTH_SHORT).show();
                startActivity(intent);

            }
        });

    }
}
