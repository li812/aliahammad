package com.example.test_1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;



public class UserHomeActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView consumer_number_view = findViewById(R.id.consumer_number_view);
        String consumer_number = getIntent().getStringExtra("Consumer Number");
        consumer_number_view.setText(consumer_number);

        Button logout_button = findViewById(R.id.logout_button);

        logout_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserHomeActivity.this, MainActivity.class);
                intent.putExtra("Consumer Number", consumer_number);
                Toast.makeText(UserHomeActivity.this, "Logout Button clicked", Toast.LENGTH_SHORT).show();
                startActivity(intent);

            }
        });

        Button generate_bill_button = findViewById(R.id.generate_bill_button);

        generate_bill_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserHomeActivity.this, BillGenerationActivity.class);
                intent.putExtra("Consumer Number", consumer_number);
                Toast.makeText(UserHomeActivity.this, "Going to Bill Generation Page", Toast.LENGTH_SHORT).show();
                startActivity(intent);

            }
        });

    }
}