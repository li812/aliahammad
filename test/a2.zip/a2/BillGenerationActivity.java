package com.example.test_1;

import android.content.Intent;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class BillGenerationActivity extends AppCompatActivity {
    private CheckBox type1Check, type2Check, type3Check;
    private EditText editBillNumber, editUnitPrice, editConsumedUnits;
    private Button showBillButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bill_generation);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI elements
        type1Check = findViewById(R.id.type_1_check);
        type2Check = findViewById(R.id.type_2_check);
        type3Check = findViewById(R.id.type_3_check);
        editBillNumber = findViewById(R.id.edit_bill_number);
        editUnitPrice = findViewById(R.id.edit_unit_price);
        editConsumedUnits = findViewById(R.id.edit_consumed_units);
        showBillButton = findViewById(R.id.show_bill_button);

        // Ensure only one checkbox is selected
        View.OnClickListener checkBoxListener = v -> {
            if (v instanceof CheckBox) {
                uncheckAll();
                ((CheckBox) v).setChecked(true);
            }
        };

        type1Check.setOnClickListener(checkBoxListener);
        type2Check.setOnClickListener(checkBoxListener);
        type3Check.setOnClickListener(checkBoxListener);

        // Button click event to calculate bill
        showBillButton.setOnClickListener(v -> showBillDetails());
    }

    // Method to uncheck all checkboxes
    private void uncheckAll() {
        type1Check.setChecked(false);
        type2Check.setChecked(false);
        type3Check.setChecked(false);
    }

    private void showBillDetails() {
        String billNumber = editBillNumber.getText().toString();
        String unitPriceStr = editUnitPrice.getText().toString();
        String consumedUnitsStr = editConsumedUnits.getText().toString();
        String type = "";

        if (type1Check.isChecked()) type = "Type 1";
        else if (type2Check.isChecked()) type = "Type 2";
        else if (type3Check.isChecked()) type = "Type 3";

        // Validate input
        if (billNumber.isEmpty() || unitPriceStr.isEmpty() || consumedUnitsStr.isEmpty() || type.isEmpty()) {
            Toast.makeText(this, "Please fill all fields and select a type", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert inputs to integers
        int unitPrice, consumedUnits;
        try {
            unitPrice = Integer.parseInt(unitPriceStr);
            consumedUnits = Integer.parseInt(consumedUnitsStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter valid numeric values", Toast.LENGTH_SHORT).show();
            return;
        }

        // Calculate total bill
        int total;
        if (type.equals("Type 1")) {
            total = (unitPrice * consumedUnits) + 700;
        } else if (type.equals("Type 2")) {
            total = (unitPrice * consumedUnits) + 1000;
        } else {
            total = unitPrice * consumedUnits;
        }

        Intent intent = new Intent(BillGenerationActivity.this,ShowBillActivity.class);
        intent.putExtra("Total",total);
        startActivity(intent);

        // Show bill details
        String message = String.format("Bill Number: %s\nType: %s\nTotal Amount: ₹%d", billNumber, type, total);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
