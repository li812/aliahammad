package com.example.test_1;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText editTextU = findViewById(R.id.editConsumerNumber);
        EditText editTextP = findViewById(R.id.editPassword);

        Button login_button = findViewById(R.id.login_button);

        login_button.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            String username = editTextU.getText().toString();
            String password = editTextP.getText().toString();
            System.out.println(username + " -> got from frontend");
            System.out.println(password + " -> got from frontend");

            if (username.equals("hi")&&password.equals("hi")){
                Toast.makeText(MainActivity.this, "Login Button clicked", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this,UserHomeActivity.class);
                intent.putExtra("Consumer Number", username);
                startActivity(intent);
            }
            else {
                Toast.makeText(MainActivity.this,"Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        }

    });

    }
}