package com.example.reg;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;




public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button login_button = findViewById(R.id.login_button);

        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (MainActivity.this, LoginActivity.class);
                Toast.makeText(MainActivity.this,"Login Button tapped", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });

        Button reg_button = findViewById(R.id.reg_button);

        reg_button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent (MainActivity.this, RegisterActivity.class);
                startActivity(intent);

            }
        });

        EditText editTextA = findViewById(R.id.a);
        EditText editTextB = findViewById(R.id.b);
        TextView sumView = findViewById(R.id.sumView);
        Button showSumButton = findViewById(R.id.show_sum);

        showSumButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String textA = editTextA.getText().toString();
                String textB = editTextB.getText().toString();

                if (textA.equals("hi") && textB.equals("hi")) {
                    Toast.makeText(MainActivity.this, "hi", Toast.LENGTH_SHORT).show();
                }

                else if (!textA.isEmpty() && !textB.isEmpty()) {
                    int a = Integer.parseInt(textA);
                    int b = Integer.parseInt(textB);
                    int sum = a + b;
                    sumView.setText("Sum is: " + sum);
                    Intent intent = new Intent (MainActivity.this, SumViewActivity.class);
                    intent.putExtra("sum", sum);
                    startActivity(intent);
                    Toast.makeText(MainActivity.this, "Sum is: " + sum, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Please enter values for both a and b", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}